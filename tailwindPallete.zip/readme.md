# TailwindColor Palette
> latest version : **v1.0.4**

TailwindColor Palette 🎨 plugin for Acode for using tailwind colors.

## Use
To use it, Search `Tailwind Color Palette` in command palette. 
And It will open a new page in which , enter tailwind color class or select from choices and click on `use button`, it will add `hsl color` of that very tailwind class in editor.

## Bug
If you found any error or bugs, please report it [here](https://github.com/bajrangCoder/acode-plugin-tailwind-palette/issues).

## Feature Request
If you have any new features idea, please suggest it [here](https://github.com/bajrangCoder/acode-plugin-tailwind-palette/issues).


> If this plugin help you, please leave a star 🌟 [here](https://github.com/bajrangCoder/acode-plugin-tailwind-palette).

**Thanks for using TailwindColor Palette Plugin and Acode ❣️❤️⭐✨**